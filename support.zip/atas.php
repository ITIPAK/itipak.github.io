<link href="index_files/bootstrap.css" rel="stylesheet" media="screen">
<link href="index_files/style.css" rel="stylesheet">
<script type="text/javascript" src="index_files/jquery.js"></script>
<script type="text/javascript" src="index_files/bootstrap.js"></script>
<script src="index_files/jquery_002.js"></script>
<script type="text/javascript" src="index_files/script.js"></script>	

			<?php
			error_reporting(E_ALL & ~E_NOTICE);
				if ($hsyncron[idcompany]=='ALL')
				{
					$image = "images/vip.jpg";
					$nama = "Admin $hsyncron[idtech]";
					$alias = "VIP Group";
				}
				else
				{
					$syncompany = "select * from mscompany where idcompany = '$hsyncron[idcompany]'";
					$qsyncompany = mysql_query($syncompany);
					$hsyncompany = mysql_fetch_array($qsyncompany);
					$image = "images/".$hsyncompany[logo];
					$nama = $hsyncompany[company];
					$alias = $hsyncompany[alias];
				}
			?>

				
				

	
			<tr align="center">
				<td>
				<div align="right"><font face="arial" size="1" color="#0000FF">Welcome <?php echo "$nama"; ?>  <br><br>
				| <a href="logout.php">Log out</a> |</font></div>
				
				<img src="<?php echo "$image"; ?>" width="780"><br>
				</td>
			</tr>
			</table>
	<table align="center" width="800">
		<tr>
			<td>
					
	<center>
	<div align="center" class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
	
		<?php
		if ($hsyncron[idcompany]=='ALL' and $hsyncron[idtech]=='ALL')
		{
		?>		
      	<li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle">Data Master<b class="caret"></b></a>
            <ul class="dropdown-menu">
                <!--<li><a href="pesananbelumlunas.php">Bayar Barang Saja</a></li>
                <li class="divider">test</li>-->
                <li><a href="mscompany.php" class="green-text">Company's Data</a></li>
                <li><a href="msdivisi.php" class="green-text">Division's Data</a></li>
				<li><a href="mstech.php" class="green-text">Technical's Data</a></li>
				<li><a href="mslogin.php" class="green-text">Login's Data</a></li>
            	<li> <a href="mspart.php">Sparepart's Data</a> </li>
				<li> <a href="mscpu.php">CPU' Data</a> </li>
			</ul>
        </li>
		
		<li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle">Transaksi Data <b class="caret"></b></a>
            <ul class="dropdown-menu">
            	<li> <a href="request.php">Request Works</a> </li>
			</ul>
        </li>
		
		<li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle">Laporan <b class="caret"></b></a>
            <ul class="dropdown-menu">
            	<li> <a href="schedule.php">Schedule</a> </li>
			</ul>
        </li>		
	<?php
						}
						else if ($hsyncron[idcompany]=='ALL')
						{
						?>
						
		      	<li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle">Master Data <b class="caret"></b></a>
            <ul class="dropdown-menu">
                <!--<li><a href="pesananbelumlunas.php">Bayar Barang Saja</a></li>
                <li class="divider">test</li>-->
				<li><a href="mspart.php" class="green-text">Sparepart List</a></li>
				<li> <a href="mscpu.php">CPU' Data</a> </li>
			</ul>
        </li>
		
		<li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle">Transaksi Data <b class="caret"></b></a>
            <ul class="dropdown-menu">
            	<li><a href="requestp.php" class="green-text">WR Baru</a></li>
				<li><a href="requestp.php" class="green-text">WR Proses</a></li>
				<li><a href="requestc.php" class="green-text">WR Close</a></li>
		        <li><a href="opname.php" class="green-text">Sparepart Opname</a></li>
				<li> <a href="rr.php">Data RR</a> </li>
				<li> <a href="pr.php">Data PR</a> </li>
				<li> <a href="gp.php">Data GP</a> </li>
			</ul>
        </li>
		
		<li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle">Laporan <b class="caret"></b></a>
            <ul class="dropdown-menu">
            	<li> <a href="schedule.php">Schedule</a> </li>
			</ul>
        </li>	   	

	<?php
	}
	else
	{
	?>

     	<li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle">Master Data <b class="caret"></b></a>
            <ul class="dropdown-menu">
                <!--<li><a href="pesananbelumlunas.php">Bayar Barang Saja</a></li>
                <li class="divider">test</li>-->
				<li> <a href="home.php">Company Proile</a> </li>
				<li> <a href="divisi.php">Divisi</a> </li>
			</ul>
        </li>
		
		<li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle">Transaksi Data <b class="caret"></b></a>
            <ul class="dropdown-menu">
            	<li> <a href="wr.php">Work Request</a> </li>
			</ul>
        </li>
		
		<li class="dropdown">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle">Laporan <b class="caret"></b></a>
            <ul class="dropdown-menu">
            	<li> <a href="schedule.php">Schedule</a> </li>
			</ul>
        </li>	
	
	  	
		
		
	  
	<?php
	}


	?>				
			  </ul>
	</div>	
	</center>
						
						</td>
		</tr>
	
				