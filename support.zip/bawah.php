<table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="75" align="center" background="images/index_32.gif">Copyright &copy; <a href="#" style="color:blue; text-decoration:none;"><?php echo "$alias	"; ?></a>.<br> 
	Analysis & Program By <a href="" style="color:blue; text-decoration:none;">IT Team</a></td>
  </tr>
</table>
