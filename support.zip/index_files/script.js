// JavaScript Document
function goBack() {
    window.history.back();
}