<?php
error_reporting(E_ALL & ~E_NOTICE);

@mysql_connect('localhost','root','');
mysql_select_db('iso');
?>